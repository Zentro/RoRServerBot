## RoRServerBot

**RoRServerBot** is the bot designed to manage and enhance how you interact with your Rigs of Rods server. It provides seamless server control, real-time chat monitoring, and easy interaction for server owners and players alike… all through the convenience of Discord!